/* CONSTANTS */

exports.config = {
  appId: "amzn1.ask.skill.a1afef7a-760d-4029-bd46-22e1aafa39ce",
  dynamoDBTableName: "my-tube",
  audioServer: "https://app.connectiongoal.com",
};

exports.kind = {
  KIND_VIDEO: "youtube#video",
  KIND_PLAYLIST: "youtube#playlist",
};

